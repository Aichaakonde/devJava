package com.example.services;

import com.example.entities.Client;
import com.example.repositories.ClientRepository;

import java.sql.SQLException;
import java.util.List;

public class ClientService {
    private final ClientRepository clientRepository;

    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    public void addClient(Client client) throws SQLException {
        clientRepository.addClient(client);
    }

    public List<Client> listClients() throws SQLException {
        return clientRepository.getAllClients();
    }

    public Client findClientByPhone(String phone) throws SQLException {
        return clientRepository.getClientByPhone(phone);
    }

}