// Repository spécifique au Client
package com.example.repositories;

import com.example.entities.Client;
import com.example.entities.User;
import com.example.datasource.DataSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClientRepository {
    private final RepositoryBDImpl repositoryBD;

    public ClientRepository(DataSource dataSource) {
        this.repositoryBD = new RepositoryBDImpl(dataSource);
    }

    // Ajouter un client
    public int addClient(Client client) throws SQLException {
        String[] fields = {"surname", "telephone", "adresse", "user_id"};
        Object[] values = {
            client.getSurname(),
            client.getTelephone(),
            client.getAdresse(),
            (client.getUser() != null) ? client.getUser().getId() : null
        };

        return repositoryBD.insert("clients", fields, values);
    }

    // Récupérer tous les clients
    public List<Client> getAllClients() throws SQLException {
        ResultSet resultSet = repositoryBD.selectAll("clients");

        List<Client> clients = new ArrayList<>();

        while (resultSet.next()) {
            Client client = mapToClient(resultSet);
            clients.add(client);
        }

        return clients;
    }

    // Récupérer un client par son ID
    public Client getClientById(Long id) throws SQLException {
        String sql = "SELECT * FROM clients WHERE id = ?";
        ResultSet resultSet = repositoryBD.getDataSource().executeQuery(sql, id);

        if (resultSet.next()) {
            return mapToClient(resultSet);
        }

        return null; // Aucun client trouvé avec cet ID
    }

    // Récupérer un client par son téléphone
    public Client getClientByPhone(String telephone) throws SQLException {
        String sql = "SELECT * FROM clients WHERE telephone = ?";
        ResultSet resultSet = repositoryBD.getDataSource().executeQuery(sql, telephone);

        if (resultSet.next()) {
            return mapToClient(resultSet);
        }

        return null; // Aucun client trouvé avec ce numéro de téléphone
    }


    // Mapper le ResultSet à l'objet Client
    private Client mapToClient(ResultSet resultSet) throws SQLException {
        Client client = new Client();
        client.setId(resultSet.getLong("id"));
        client.setSurname(resultSet.getString("surname"));
        client.setTelephone(resultSet.getString("telephone"));
        client.setAdresse(resultSet.getString("adresse"));

        // Mapper l'utilisateur associé
        User user = new User();
        user.setId(resultSet.getLong("user_id"));
        client.setUser(user);

        return client;
    }


}