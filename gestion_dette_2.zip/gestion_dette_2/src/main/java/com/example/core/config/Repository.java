package com.example.core.config;

import java.util.List;

public interface Repository<T> {
    void add(T objet);
    List<T> selectAll();
}
