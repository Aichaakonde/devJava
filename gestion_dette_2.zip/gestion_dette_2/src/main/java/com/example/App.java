package com.example;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.example.datasource.DataSource;
import com.example.datasource.MySQLDataSourceImpl;
import com.example.datasource.PostgreSQLDataSourceImpl;
import com.example.repositories.ClientRepository;
import com.example.services.ClientService;
import com.example.entities.Client;


public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            // Choisissez votre implémentation MySQL ou PostgreSQL
            //DataSource dataSource = MySQLDataSourceImpl.getInstance(); 
            DataSource dataSource = PostgreSQLDataSourceImpl.getInstance(); 

            // Initialisation du dépôt et du service client
            ClientRepository clientRepository = new ClientRepository(dataSource);
            ClientService clientService = new ClientService(clientRepository);

            while (true) {
                System.out.println("1. Créer un client");
                System.out.println("2. Lister les clients");
                System.out.println("3. Rechercher un client par téléphone");
                System.out.println("4. Quitter");
            

                int choix = Integer.parseInt(scanner.nextLine());

                switch (choix) {
                    case 1:
                        System.out.println("Entrez le nom du client:");
                        String name = scanner.nextLine();
                        System.out.println("Entrez le téléphone du client:");
                        String phone = scanner.nextLine();
                        System.out.println("Entrez l'adresse du client:");
                        String address = scanner.nextLine();

                        Client client = new Client(null, name, phone, address, null);
                        clientService.addClient(client);
                        System.out.println("Client créé avec succès.");
                        break;

                    case 2:
                        List<Client> clients = clientService.listClients();
                        clients.forEach(c -> System.out.println(c.getSurname() + " - " + c.getTelephone()));
                        break;

                    case 3:
                        System.out.println("Entrez le téléphone du client:");
                        String searchPhone = scanner.nextLine();
                        Optional<Client> foundClient = Optional.of(clientService.findClientByPhone(searchPhone));
                        foundClient.ifPresentOrElse(
                                c -> System.out.println(c.getSurname() + " - " + c.getTelephone()),
                                () -> System.out.println("Client non trouvé."));
                        break;

                    case 4:
                        System.out.println("Au revoir !");
                        System.exit(0);

                    default:
                        System.out.println("Choix invalide !");
                }
        }

        } catch (Exception e) {
            System.err.println("Une erreur est survenue : " + e.getMessage());
            e.printStackTrace();
        }
    }
}